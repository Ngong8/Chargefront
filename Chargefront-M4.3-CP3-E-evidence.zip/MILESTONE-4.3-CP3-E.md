# Milestone 4.3 — CP3-E final integration and regression

**CP3-E verification complete — ready for qualified manual gameplay review.**
7 November 2026. The M4 alarm-latch persistence defect is corrected. All **43
latest test/capture combinations pass**; Firefox frame pacing remains an explicit
acceptance qualification. No CP4/CP5 work, commit or push was performed.

## Handover and confirmed baseline

- Repository: `C:/Game projects/GenAI projects/Chargefront`.
- Branch: `milestone-4.3`; HEAD: `b2aae3a72026070f6f1f02c502723f922e3e08d0`.
- Previous implementation: `0f1b2301e0c6c5adc6b24f4e8bc7d9ba1f6f2184`.
- Initially no tracked/index changes. Existing untracked evidence was inventoried
  in [baseline-status.txt](_playtest/m43/cp3/e/baseline-status.txt). Existing
  `milestone-4.2` GitHub Desktop stash was listed and preserved.
- No project copy, branch switch, reset, clean, restore, rebase, staging, commit,
  merge, tag or push. CP4, CP5 and Milestone 4.4 are outside this checkpoint.

Read README, CP0/CP0-R, CP1/CP2/CP2-R and CP3-A/B/C/D/R, and the relevant 4.2
environment/CP4 acceptance qualifications. Later amendments supersede historical
claims in those reports: fresh Endless supplies are 6/3, fresh Director plans
are v2, Replay refreshes encounter variation, and Campaign results have no direct
Endless navigation.

## Architecture and invariants

| Owner | Responsibility and protected invariant |
|---|---|
| `chargefront.html` | Game loop, Campaign chapters, actors/AI integration, waves/interactions, upgrades/crafting, audio dispatch, save boundaries and result UI. |
| `src/progression.js` | Separate Campaign v4 / Endless v1 validation and backup handling; authored Campaign reserves/drop economy; contextual Endless rewards and bounded DNA dividends. No save-format change in CP3-E. |
| `src/results.js` | Frozen terminal snapshots; canonical earlier chapter totals plus current attempt; reached versus cleared waves. Repeated terminal calls cannot change the debrief. |
| `src/enemy-tactics.js`, HTML `Infested` | Role policies, height-aware LOS, memory/search, wind-ups and bounded obstacle detours. Unseen Endless contacts advance toward the relay. |
| HTML `SquadMember`, `src/combat.js` | Existing squad commands/abilities; full loaded magazines, shared player cartridges, sanitized selected deployment. No CP4 squad work. |
| `src/endless-director.js` | Versioned seeded family plans, staged roles, live/threat/source caps and boss-every-eight cadence. Failed spawn requests retain queued entries. |
| `src/world/endless-terrain.js` and HTML world builder | Valley lowland / crater basin / crossing ridges. Actual mesh-triangle grounding; intentional relay clearing; scenery/collision fingerprints reconstruct from arena/world seed. |
| HTML `endlessRandom` / variation initialization | Independent saved decision/event streams. Continue resumes a wave-start or paid-clear boundary, never an arbitrary mid-frame save. Legacy v1 encounters and saved active mutators remain compatible. |
| HTML relay terminal | Three weighted randomized offers. Turret eligible from wave 10/Tier 3, costs 24 scrap, ownership persists on Continue and resets on Replay. Eligibility does not guarantee an immediate offer. |

Replay keeps the current world/arena and deployment, reuses its geometry, resets
resources/upgrades/statistics and derives a fresh encounter seed. Continue may
rebuild the world; equality means terrain/scenery/collision content, not a GPU
object UUID across a rebuild. Fresh deployment uses the existing arena pool.
Native Main Menu exits reload the document, and Continue constructs its world in
that new document. A diagnostic hook invoked repeatedly inside an existing run
does not model that lifecycle.

The authored timing is **90 seconds for M3's sample stabilization defence**, then
DNA transfer and the seamless M3→M4 transition. M4 carries secured DNA and retains
the existing **120-second extraction holdout**. The handover's reference to an
M4 90-second defence is interpreted against that established source/README
sequence; no mission timer or chapter identity was changed.

## CP3 integration status

| Checkpoint | Final finding |
|---|---|
| CP3-A | PASS: all three arenas × both browsers; distinct non-flat geometry, aligned scenery/collision, native relay/vial access, saved terrain and no-rebuild Replay. Dark purple/magenta atmosphere retained and final captures opened locally. |
| CP3-B / CP1 / CP2-R | PASS: 8,192 seeded plans plus focused retry/boss/brood/watchdog lifecycle checks; 40 native queue lifecycles per browser; active/incoming accounting and live/threat caps. Native early combat and six 20-second wave-12/24/40 windows cover real AI/projectile behaviour. |
| CP3-C | PASS: native loot generation/collection/crafting, old-wallet Continue, DNA/brood/Rain checks and 3,200 updated ledger waves. Poor collection and finite-upgrade surplus remain manual balance concerns; no further reductions. |
| CP3-D | PASS: seeded family variation, high-uint32 RNG Continue despite 5,000 unrelated draws, compatible saved Storm, rifle-less future Storm exclusion, retained deployment/world and fresh Replay encounters. |
| CP3-R | PASS after the two-line M4 latch fix: 6/3 fresh supplies, saved partial magazines/reserves, randomized Tier-3 turret eligibility/purchase/Continue/Replay, isolated drone audio and once-only transfer alarm. |

Campaign protection passes include four-chapter progression, seamless M3→M4,
carried actors/statistics, standalone M4/unlock separation, result idempotence and
navigation, turret LOS/range, facility doors/staged seal/lighting and the full
unaccelerated sample defence in both browsers. Defence receipts observe the vial
through 89 seconds and transfer at exactly 90 simulated seconds; wall time includes
intentional pauses/captures and transfer (Edge 97.04 s, Firefox 128.63 s).

## Corrections and files

**Confirmed integration defect:** CP3-R set `m4AlarmPlayed` during transition,
but M4 uses specialized `createContinuedMission4Snapshot` /
`applyContinuedMission4Snapshot` functions rather than the generic `worldState`
checkpoint. Those functions omitted the latch. The added test reproduced a
missing latch after actual persistent M4 Continue in both Edge and Firefox.
Restore remained silent, but the promised saved one-time guard was lost.

**Minimal correction:** `chargefront.html` adds exactly two lines to serialize
and restore that optional boolean. The existing v4 format, alarm trigger,
mission progression, balance, terrain and lighting remain unchanged. Legacy
checkpoints without the field still restore silently. Post-fix Edge/Firefox
tests verify the stored field, restored field, zero resumed alarms and legacy
compatibility. All `src/` modules are unchanged; the final audit compares the
remaining HTML exactly against HEAD after removing only those two added lines.

Files modified, in addition to that two-line production correction:

- `tests/endless-{director,economy,replayability}-state.mjs`: respect
  `CF_ARTIFACT_DIR` for new receipts; keep historical baseline inputs read-only.
- `tests/endless-director.mjs`: use the run's encounter seed/planner version and
  accepted 6-cartridge Replay reserve. Explicit legacy-migration fixture retained.
- `tests/endless-terrain.mjs`, `tests/endless-economy.mjs`: accepted fresh reserve
  expectation; fix cartridge-consumption reporting to subtract from actual initial
  reserves. Carrier materials use the event stream, which safe brood-spawn searches
  also consume; assert the unchanged 5–6 Carrier scrap table and one-unit brood
  scrap rather than assuming a global `.1` RNG override forces five.
- `tests/results-flow.mjs`: advance the real minimum recovery between its six
  accelerated clear fixtures, so the real K extraction input reaches wave six.
  Result values, navigation and extraction assertions are retained.
- `tests/cp3r.mjs`: add Firefox launch support; retain 32 audio guard configurations
  evaluated twice (64 evaluations), supply/Continue/Replay and randomized turret
  purchase assertions; add actual persistent M4 Continue/alarm-latch coverage.
- `tests/helpers/endless-economy-model.mjs`: optional current-run mode for CP3-D
  streams/loadout eligibility and CP3-R 6/3 supplies. Historical model defaults
  remain for existing comparison fixtures.
- New `tests/cp3e-run.mjs`, `tests/cp3e-extended.mjs`, `tests/cp3e-economy.mjs`,
  `tests/cp3e-evidence.mjs`: serial receipt runner, bounded native queue/cycle/CPU
  fixtures, updated economy ledger and local index/preservation checks.
- This report and new evidence only under `_playtest/m43/cp3/e/`.

## Economy findings

Updated ledger: **16 seeds × five profiles × 40 waves = 3,200 modeled waves**,
using current v2 plans, saved event/decision streams, weapon eligibility and 6/3
reserves. Actual shipped reward/crafting/banking/upgrade functions are executed.
Collection, accuracy, medical demand and brood births remain estimates. Unfunded
reloads are explicitly recorded as counterfactual debt, not successful survival.

| Profile | Mean final scrap | Mean final cells | Unfunded reloads | Missing-ammo scrap debt |
|---|---:|---:|---:|---:|
| Balanced | 2,589.69 | 105.56 | 0.625 | 1.81 |
| Rifle squad | 2,191.75 | 104.56 | 2.75 | 8.75 |
| Efficient Arc/Plasma | 3,368.06 | 120.94 | 0 | 0 |
| Repeated-Rain stress ceiling | 2,969.19 | 186.38 | 0 | 0 |
| Low collection | 269.50 | 48.75 | 114.75 | 413.56 |

Low-collection final scrap includes injected shortfall funding and must not be
read as a sustainable wallet: subtracting the 413.56 debt gives **−144.06 scrap**.
Repeated Rain intentionally exceeds legal no-repeat frequency to measure a ceiling.
Generated and collected resources are separate in the receipts. Late surplus
after finite upgrades and poor-collection ammo starvation remain manual concerns;
there is no evidence here to justify arbitrary additional reductions. Campaign
economy and all live balance values remain unchanged.

## Browser and performance findings

Corrected Edge **156.0.4314.58** and Firefox **159.0** observations, 1280×720,
isolated headless/software rendering, no competing test browser. These extended
samples use Valley / seed **1039130682** in Edge and Crater / seed **1147190197**
in Firefox; their cross-browser numbers are observations, not paired arena tests.

| Controlled sample | Edge p95 / worst frame | Firefox p95 / worst frame |
|---|---|---|
| 24 mixed actors, six 5-second windows | 16.8–17.0 / 50.1 ms | 50.0–66.7 / 83.4 ms |
| Separate 8-second squad/projectile combat | 33.4 / 83.2 ms | 83.4 / 1,033.6 ms |
| Native wave 12 / 24 / 40 windows | 50.1 / 50.0 / 17.2 ms p95; worst 66.9 ms | 66.7 / 50.0 / 66.7 ms p95; worst 616.8 ms |
| Existing facility A–E controlled traversal | 33.3 / 150.0 ms | 50.0 / 183.4 ms |

Edge's 30-second weighted actor update cost is **0.00919 ms/call**; its first
five-second window is **0.01257 ms/call**. The parked 24-actor phase adds no
world/terrain/facility/nav rebuild or shader link. Actual live-combat windows are
reported separately, including outliers; no FPS improvement is claimed from a
passing CPU threshold.
Firefox's corresponding weighted actor cost is **0.00657 ms/call**; lower actor
CPU time does not imply faster total rendering or better frame pacing.

All six corrected Edge reload cycles contain **one world / 267 geometries /
two textures**; Firefox stays at **one world / 249 geometries / two textures**.
Both retain their arena and terrain fingerprint, and those renderer counts remain
stable through their warmed 30-second samples. Chromium's coarse
page-heap reading stays **42.1 MB**; it is not precise process/GPU memory telemetry,
and Firefox does not expose that Chromium heap API. This is bounded lifecycle
coverage, not an hour-long memory certification.

The retained CP3-D four-second/24-actor Edge sample reported approximately
0.0096 ms/actor and p95 18.5 ms; this checkpoint's existing replayability suite
recorded 0.0131 ms/actor and p95 16.8 ms under that short protocol. The longer
sample above includes actors reaching the relay and doing less work. Test dates,
browser builds and workload conditions differ, so these are reference readings,
not a controlled performance improvement/regression attribution. Historical
CP1/CP2 already records substantially slower Firefox software-rendered pacing.
The current facility outliers remain a normal-profile manual acceptance concern.
Firefox's current 1.03-second combat hitch is also disclosed; its origin is not
attributed to Milestone 4.3 solely from this unpaired extended sample.

**Additional paired Firefox comparison:** the existing `tactical-performance`
suite uses the preserved pre-CP1 HTML and current HTML in the same Firefox build,
Crater seed 430012, 18 identical initial actors/positions and eight-second samples.
Only the preserved HTML's asset base URL changes; no project copy is created.

| Paired protocol | Pre-CP1 → current p95 | Worst frame | Added measured CPU for 18 actors/tick |
|---|---:|---:|---:|
| Stationary policy | 16.7 → 33.3 ms | 33.4 → 66.7 ms | +0.0146 ms |
| Live combat | 33.3 → 50.0 ms | 50.0 → 66.7 ms | +0.0667 ms |

CPU/resource gates pass, with no shader/world/nav rebuilds, but this run shows
**worse current Firefox frame pacing**. It is not dismissed as wholly pre-existing.
The comparison spans the accepted non-flat Crater/scenery correction as well as
the AI changes; it does not isolate their individual render costs. The 1.03-second
hitch was not reproduced in these shorter paired windows, which does not establish
its absence. No speculative terrain/lighting redesign was made. Treat Firefox
normal-profile performance as an unresolved manual acceptance risk, separate from
the corrected save-latch defect and the invalid synthetic Continue protocol.

## Verification and evidence

Terrain numerical checks agree in Edge/Firefox: interior height ranges
**13.52 / 12.64 / 15.13 m**, sampled maximum grades **.331 / .207 / .505**,
and maximum rendered-triangle/ground error **3.29e-14 m**. Both browsers pass
four native movement legs per arena, relay/vial accessibility, scenery alignment,
unseen advancement, Continue at seven stored cartridges and fresh Replay at six.
The intentional flat relay pad remains; there is no unexpectedly flat arena.

The authoritative updated suite table is
[suite-status.md](_playtest/m43/cp3/e/suite-status.md); retained attempts are listed
separately from latest outcomes in
[verification.json](_playtest/m43/cp3/e/verification.json).

Final totals: **13 state suites + one economy-model suite + 28 asserting browser
suite/argument combinations + one arena-capture run = 43 latest PASS / 0 FAIL**.
This counts suite/browser/argument combinations, not individual assertions.
There are **10 retained failed/aborted attempts**: seven environment/runner/stale
fixture failures, two real pre-fix M4 latch failures and one deliberately stopped
invalid Firefox performance protocol. The invalid initial Edge performance pass is
also qualified explicitly. Post-fix coverage reruns the affected progression,
result, Campaign-protection and terrain state suites, CP3-R in both browsers and
the full Edge result lifecycle. Earlier broad results/performance receipts predate
only the two metadata lines, whose exact production scope is audited.

Final checks PASS: module/modified/new-script syntax, `git diff --check`, exact
two-line production allowlist, unchanged `src/`, unchanged branch/HEAD, empty index,
unchanged stash, and all **1,631** original untracked paths still present. New
artifacts remain under `e/`; no historical evidence was deleted or overwritten.

- [Local visual/evidence index](_playtest/m43/cp3/e/INDEX.html).
- [Evidence guide](_playtest/m43/cp3/e/README.md).
- [Initial 13 Node suites](_playtest/m43/cp3/e/state-runs.json).
- [Seeded plans](_playtest/m43/cp3/e/endless-replayability-state/seeded.json).
- [Normal-speed early wave, RNG Continue, Replay and all-arena arrivals](_playtest/m43/cp3/e/endless-retry-endless-replayability/replayability.json).
- [Three-arena comparison image](_playtest/m43/cp3/e/endless-retry-endless-replayability/run-comparison.png), opened locally during review.
- [Updated economy ledgers](_playtest/m43/cp3/e/current-economy-model/ledger.json).
- [Corrected Edge extended receipt](_playtest/m43/cp3/e/corrected-cp3e-extended/edge/extended.json) / [Firefox](_playtest/m43/cp3/e/corrected-cp3e-extended-firefox/firefox/extended.json).
- [Paired Firefox measurements](_playtest/m43/cp3/e/paired-tactical-performance-firefox/firefox/performance.json).
- [Post-fix regression receipts](_playtest/m43/cp3/e/postfix-runs.json).

Environment/attempt ledger: the first sandboxed Edge launch failed before gameplay;
isolated browsers run outside the Windows sandbox. The initial new runner also
precreated directories rejected by existing fresh-evidence guards and accidentally
treated a batch label as a suite. These harness errors were corrected and retained.
The first economy and debrief failures led to the specific fixture fixes above.
No failure is erased, no product assertion is bypassed and no historical artifact
is overwritten. The installed Playwright package's required Firefox was absent;
Firefox 159.0 / Playwright build 1572 was provisioned in its external browser cache.

The initial extended Edge receipt is **not a native performance baseline**:
repeated in-place diagnostic Continue calls stacked world builds (renderer
geometries 777→1,776, textures 3→13), making its later frame measurements invalid
for the menu lifecycle. Source tracing confirmed native menu exit reloads the
document. The analogous Firefox attempt was deliberately stopped; its console
retains the completed 40-wave queue observation. The corrected harness performs
six actual document reload/Continue cycles per browser, checks one ground/world,
and measures warmed performance afterward. This does not justify a speculative
production disposal redesign or an assertion that normal Continue leaks worlds.

Tooling: Node **24.20.0**, external Playwright **1.65.0**. Browsers use temporary,
isolated profiles and 1280×720 unless a suite explicitly checks other layouts
(the normal-speed defence/lighting fixtures use 1600×900). Game runtime CDNs
remain the existing dependency; no project package installation/build was added.

Reproduction example (use a new batch label; existing evidence destinations are
deliberately protected against replacement):

```powershell
$env:PLAYWRIGHT_PACKAGE='C:/Users/User/AppData/Local/Temp/opencode/chargefront-cp3r-tools/node_modules/playwright/index.mjs'
$env:CF_ENABLE_LAB_TURRET='1'
node tests/cp3e-run.mjs review-01 cp3r 'cp3r firefox' endless-economy 'endless-director --only=lifecycle' results-flow 'results-flow firefox'
# Run other recorded jobs with another fresh batch label; see suite-status.md.
node tests/cp3e-run.mjs review-extended-01 cp3e-extended 'cp3e-extended firefox' sample-lockdown-live 'sample-lockdown-live firefox'
node tests/cp3e-run.mjs review-model-01 cp3e-economy
```

## Manual acceptance and next checkpoint

Automated input, real-time AI and timed defence observations are not a human
playthrough. Review in a normal desktop browser:

1. All three arena silhouettes, slope feel, relay/vial access and dark-purple
   target readability with movement; compare the linked overview images.
2. Family variation, wave-five seams, bosses/airborne coincidences, wind-up cues
   and recovery pacing through early/middle/later waves.
3. Ammo sharing/collection paths during waves 12–24, especially rifle squads and
   poor collection; contrast efficient Arc/Plasma surplus. Observe before retuning.
4. U terminal, randomized offer refresh, numbered turret purchase and firing;
   Continue ownership/offers and fresh Replay reset.
5. Audible alarm once after DNA transfer, no alarm from Endless drones, retained
   lasers/explosions and volume/music behaviour. Dispatch checks do not certify
   subjective speaker output.
6. Both debriefs and native navigation after a real failure/extraction, saved-run
   Continue and mode switching; verify chosen deployment and arena on Replay.
7. Long normal-profile Campaign/Endless sessions on actual hardware, including
   Firefox frame pacing and startup variability.

Relevant unresolved 4.2 risks: no 4.2 CP5 final/manual acceptance record was found;
cold-build/CDN startup, facade/frame-time variability, simplified legacy scatter
collision and the approved legacy ingress/rally safety exception remain qualified.
Later CP4 geometry corrections must not be confused with the earlier deferred
interior Z-fighting note. This checkpoint does not reopen accepted facility design
or assert that every camera angle/legacy save is visually defect-free.

CP4 recommendation only: prioritize measured squad ammo-sharing/formation recovery
and path behaviour identified by human play, keeping Campaign progression, the
bounded Director, economy and save/result ownership protected. Start no CP4/CP5
work until this checkpoint's manual acceptance is given.
