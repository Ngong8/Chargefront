# CP3-E evidence guide

Start with [INDEX.html](INDEX.html) for local image previews and receipt links, or
the [checkpoint report](../../../../MILESTONE-4.3-CP3-E.md) for findings and limits.

- [Latest suite status](suite-status.md): one latest attempt per suite/argument set.
- [Repository and syntax receipt](verification.json): exact branch/HEAD, protected
  production files, empty staging index, preserved stash and original untracked
  paths. `failedAttempts` retains earlier failures and test-driver mistakes.
- [Final link audit](link-check.json): report, guide, suite table and local index
  links resolve; all latest suite outcomes pass.
- [Initial quick checks](state-runs.json): 13 passing Node/state suites.
- [Post-helper checks](state-post-runs.json): affected economy/RNG/protection suites.
- [Browser matrix](final-runs.json): serial isolated Edge/Firefox jobs and logs.
- [Native replayability](endless-retry-endless-replayability/replayability.json):
  normal-speed early wave, saved RNG, legacy mutator, native debrief Replay,
  three-arena wave-12 advancement/caps and four-second historical-protocol CPU smoke.
- [Arena comparison](endless-retry-endless-replayability/run-comparison.png):
  Valley, Crater and Ridges in the accepted dark lighting.
- [Current economy model](current-economy-model/ledger.json): 3,200 estimated wave
  ledgers, including generated/collected materials and explicitly unfunded reloads.
  The repeated-Rain profile is a stress ceiling, not legal ordinary sequencing.
- `corrected-cp3e-extended*/{edge,firefox}/extended.json`: accelerated real 40-wave
  queue soak, six real reload/Continue cycles per browser, turret damage, separate
  30-second 24-actor samples and normal-speed wave-12/24/40 windows.
  Administrative fixture clearing, invulnerability and stocked ammo are disclosed.
- `final-cp3e-extended/edge/extended.json` is a superseded diagnostic protocol:
  in-place Continue bypassed the menu reload, stacking world builds. Its native
  render/memory findings are invalid. The analogous Firefox attempt was stopped.
- `final-sample-lockdown-live*/live-{edge,firefox}/manifest.json`: unaccelerated
  90-second sample defence, transfer, safe doors, visible vial and carried turret.

Full paths for each browser-specific receipt are linked by the generated index;
the trailing `firefox` in a job name means that suite runs Firefox. CP3-R emits
its structured cases to its console log rather than a separate JSON file.

Early directories/logs are preserved even when superseded by corrected fixtures.
They are not passing acceptance receipts. Historical evidence outside this `e/`
folder was not deleted or overwritten. Each browser uses isolated temporary
storage; these tests do not operate the user's normal browser saves.

Automation is not human manual acceptance, a forty-wave survival claim, subjective
speaker/audio QA, or an on-device GPU/FPS certification. Read the report's fixture
limits and the retained baseline performance qualifications before interpreting
any timing difference.
