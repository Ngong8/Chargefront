| Suite | Latest result | Seconds | Receipt |
|---|---|---:|---|
| combat-state | PASS | 0.4 | [log](combat-state/console.log) |
| progression-state | PASS | 0.1 | [log](postfix-progression-state.log) |
| objective-hud-state | PASS | 0.1 | [log](objective-hud-state/console.log) |
| relay-routing-state | PASS | 0.2 | [log](relay-routing-state/console.log) |
| environment-placement-state | PASS | 0.1 | [log](environment-placement-state/console.log) |
| campaign-terrain-state | PASS | 0.8 | [log](campaign-terrain-state/console.log) |
| enemy-tactics-state | PASS | 0.2 | [log](enemy-tactics-state/console.log) |
| results-state | PASS | 0.5 | [log](postfix-results-state.log) |
| cp2r-state | PASS | 0.4 | [log](postfix-cp2r-state.log) |
| endless-terrain-state | PASS | 0.6 | [log](postfix-endless-terrain-state.log) |
| endless-director-state | PASS | 0.5 | [log](endless-director-state/console.log) |
| endless-economy-state | PASS | 1.1 | [log](state-post-endless-economy-state.log) |
| endless-replayability-state | PASS | 10.4 | [log](state-post-endless-replayability-state.log) |
| cp3r | PASS | 35.3 | [log](postfix-cp3r.log) |
| endless-replayability | PASS | 139.9 | [log](endless-retry-endless-replayability.log) |
| endless-economy | PASS | 75.1 | [log](corrected-endless-economy.log) |
| results-flow | PASS | 88.6 | [log](postfix-results-flow.log) |
| endless-unlock | PASS | 214.5 | [log](campaign-endless-unlock.log) |
| campaign-tactics | PASS | 35.4 | [log](campaign-campaign-tactics.log) |
| cp3r firefox | PASS | 43.5 | [log](postfix-cp3r-firefox.log) |
| endless-director --only=lifecycle | PASS | 27.6 | [log](final-endless-director---only=lifecycle.log) |
| endless-terrain | PASS | 92.3 | [log](final-endless-terrain.log) |
| endless-terrain firefox | PASS | 157.3 | [log](final-endless-terrain-firefox.log) |
| tactical-ai | PASS | 56.3 | [log](final-tactical-ai.log) |
| tactical-ai firefox | PASS | 84.1 | [log](final-tactical-ai-firefox.log) |
| enemy-cover | PASS | 18.4 | [log](final-enemy-cover.log) |
| enemy-cover firefox | PASS | 30.1 | [log](final-enemy-cover-firefox.log) |
| results-flow firefox | PASS | 142.6 | [log](final-results-flow-firefox.log) |
| endless-unlock firefox | PASS | 201.0 | [log](final-endless-unlock-firefox.log) |
| campaign-tactics firefox | PASS | 41.4 | [log](final-campaign-tactics-firefox.log) |
| facility-e-integration | PASS | 42.4 | [log](final-facility-e-integration.log) |
| facility-e-integration firefox | PASS | 60.0 | [log](final-facility-e-integration-firefox.log) |
| facility-regression | PASS | 31.9 | [log](final-facility-regression.log) |
| facility-regression firefox | PASS | 59.8 | [log](final-facility-regression-firefox.log) |
| facility-persistent-lighting | PASS | 38.5 | [log](final-facility-persistent-lighting.log) |
| facility-persistent-lighting firefox | PASS | 40.3 | [log](final-facility-persistent-lighting-firefox.log) |
| cp3e-extended | PASS | 173.8 | [log](corrected-cp3e-extended.log) |
| cp3e-extended firefox | PASS | 242.1 | [log](corrected-cp3e-extended-firefox.log) |
| sample-lockdown-live | PASS | 113.5 | [log](final-sample-lockdown-live.log) |
| sample-lockdown-live firefox | PASS | 151.4 | [log](final-sample-lockdown-live-firefox.log) |
| cp3e-economy | PASS | 5.4 | [log](corrected-cp3e-economy.log) |
| endless-terrain --capture-only | PASS | 34.4 | [log](corrected-endless-terrain---capture-only.log) |
| tactical-performance firefox | PASS | 134.7 | [log](paired-tactical-performance-firefox.log) |
